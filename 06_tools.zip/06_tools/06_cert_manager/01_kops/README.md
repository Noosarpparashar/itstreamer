## Route53
https://cert-manager.io/docs/configuration/acme/dns01/route53/

## Uninstall cert-manager
https://docs.cert-manager.io/en/release-0.11/tasks/uninstall/kubernetes.html


kubectl get cert,certificaterequest,order,challenge -A
