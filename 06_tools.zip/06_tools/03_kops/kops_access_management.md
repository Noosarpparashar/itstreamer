To Debug
` aws sts assume-role --role-arn arn:aws:iam::ACCOUNT:role/ROLE --role-session-name test`
` aws sts assume-role --role-arn arn:aws:iam::617960797257:role/kubernetes_viewer --role-session-name test`
