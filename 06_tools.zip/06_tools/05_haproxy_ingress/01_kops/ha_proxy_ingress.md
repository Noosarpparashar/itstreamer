## Installation
https://www.haproxy.com/documentation/kubernetes/latest/installation/

### Installation on AWS 
https://www.haproxy.com/documentation/kubernetes/latest/installation/community/aws/
