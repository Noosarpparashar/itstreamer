`eksctl create cluster --name robin-personal-cluster --fargate`

`eksctl create cluster -f cluster.yaml`


`eksctl delete cluster --name robin-personal-cluster`


`kubectl describe configmap -n kube-system aws-auth`
